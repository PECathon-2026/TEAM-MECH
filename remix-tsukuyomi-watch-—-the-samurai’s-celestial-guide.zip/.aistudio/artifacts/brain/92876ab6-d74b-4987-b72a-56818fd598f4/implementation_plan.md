# Tsukuyomi Watch — The Samurai's Celestial Guide (Redesign Plan)

A comprehensive visual and structural redesign of **Tsukuyomi Watch**, elevating the astronomy guide into a polished, high-contrast Japanese celestial observatory. This plan enhances heading hierarchy, introduces a revolving SVG vector moon with an orbital ring, adds a performance-optimized dynamic canvas starfield, and reorganizes all four core sections into high-legibility cards and controls.

> [!IMPORTANT] Confirmed User Choices (Phase 1)
> - **Revolving Moon Style**: SVG vector moon illustration with smooth slow rotation, crater detail shading, soft moonlight halo, and orbiting satellite ring.
> - **Background & Starfield**: Dynamic HTML5 canvas starfield with drifting stars, randomized twinkling intervals, and soft deep indigo nebulae gradients (`#080D1A` to `#10182A`).
> - **Navigation Architecture**: Sticky top navigation bar featuring a 1-row header contract with rapid smooth-scroll jump links to all major sections and a primary stargazing status button.

---

## 1. Overview & Core Concept

**Tsukuyomi Watch** unites traditional Japanese celestial aesthetics with precision modern astronomy tools. The application provides stargazers, night-sky photographers, and amateur astronomers with:
- **WATCHTOWER**: Real-time stargazing weather analysis and the calculated **Night Honor Score**.
- **CELESTIAL SCROLL**: Curated list and filtering of meteor showers, eclipses, lunar phases, ISS passes, and rocket launches.
- **SPIRIT LENS**: AI-powered astronomical image enhancement and deep-sky object detection powered by server-side Gemini 3.8 Flash (`@google/genai`).
- **DOJO DASHBOARD**: Comprehensive executive summary integrating active weather, moon phase, upcoming events, and recent astronomical photo analyses.

---

## 2. User Experience & Visual Design

### A. Typographic Hierarchy & Dominant Headings
- **Major Section Titles**: 36–48px on desktop, 28–36px on mobile. Rendered in warm moon-white (`#F3F0E8`) with restrained antique gold (`#D6AD60`) accents, paired with subtle Japanese celestial symbols (`✦`, `☽`, `⛩`) and thin decorative gold dividers.
- **Subtitles**: Descriptive 14–16px subtitles placed directly below each main title explaining the section function in clear prose.
- **Body & Controls**: High-contrast silver-gray (`#A7B2C5`) body text at 15–17px, with clear unboxed metadata (`·` separators) and tabular numbers (`tabular-nums`) for coordinates and metrics.

### B. Revolving Moon & Dynamic Background
- **Revolving Moon**: Positioned tastefully in the hero area. Features crisp SVG crater textures, soft lunar shadowing, an orbiting ring, and calm continuous rotation without overlapping text or interactive controls.
- **Dynamic Starfield**: Canvas-rendered background with low star count for 60fps performance, random twinkling rates, slow multi-directional drift, and deep indigo nebula backdrops. Respects `prefers-reduced-motion`.

### C. Palette & Theme Enforcement
- **Midnight Navy Canvas**: `#080D1A`
- **Deep Indigo Atmosphere**: `#10182A`
- **Card Surfaces**: `#172238` with 1px hairline borders (`rgba(214, 173, 96, 0.15)`)
- **Moon-White Display**: `#F3F0E8`
- **Silver-Gray Body**: `#A7B2C5`
- **Antique Gold Accent**: `#D6AD60`
- **Japanese Crimson Accent**: `#C94C5A` (reserved strictly for critical weather warnings or key CTA accents)

---

## 3. Key Product Decisions & Trade-Offs

1. **Header Contract**: Enforce a strict 3-zone single-row sticky header (Brand Title — 4 Jump Links — Stargazing Status CTA) to maximize viewport space and prevent visual clutter.
2. **Server-Side Gemini API for Spirit Lens**: All astronomical image analysis and object detection requests will execute on an Express backend proxy route (`/api/spirit-lens`) utilizing `@google/genai` and model `gemini-3.8-flash`.
3. **Canvas Starfield Performance**: Utilize a single `<canvas>` backdrop layered behind card surfaces to guarantee lightweight rendering without causing layout reflows or interfering with form controls.

---

## 4. Technical Architecture & Data Strategy

```
┌────────────────────────────────────────────────────────────────────────┐
│                        TOP STICKY NAVIGATION BAR                       │
│  [ Tsukuyomi Watch ☽ ]  —  [ Watchtower | Scroll | Lens | Dojo ]  — [ Status ]│
└────────────────────────────────────────────────────────────────────────┘
                                   │
┌──────────────────────────────────┴─────────────────────────────────────┐
│                    DYNAMIC CANVAS STARFIELD & NEBULAE                   │
│                                                                        │
│  ┌──────────────────────────────────────────────────────────────────┐  │
│  │ HERO: Revolving SVG Vector Moon & Celestial Welcome Kicker       │  │
│  └──────────────────────────────────────────────────────────────────┘  │
│                                                                        │
│  ┌──────────────────────────────────────────────────────────────────┐  │
│  │ 1. WATCHTOWER (Night Honor Score & Weather Condition Cards)      │  │
│  └──────────────────────────────────────────────────────────────────┘  │
│                                                                        │
│  ┌──────────────────────────────────────────────────────────────────┐  │
│  │ 2. CELESTIAL SCROLL (Filterable Meteor Showers, Eclipses & ISS)  │  │
│  └──────────────────────────────────────────────────────────────────┘  │
│                                                                        │
│  ┌──────────────────────────────────────────────────────────────────┐  │
│  │ 3. SPIRIT LENS (Image Enhancement, Comparison Slider & Gemini AI) │  │
│  └──────────────────────────────────────────────────────────────────┘  │
│                                                                        │
│  ┌──────────────────────────────────────────────────────────────────┐  │
│  │ 4. DOJO DASHBOARD (Grid Summary Cards & Activity Insights)      │  │
│  └──────────────────────────────────────────────────────────────────┘  │
│                                                                        │
└────────────────────────────────────────────────────────────────────────┘
                                   │
                     ┌─────────────┴─────────────┐
                     │ Express Server (/server)   │
                     │ POST /api/spirit-lens     │
                     │ GoogleGenAI @google/genai  │
                     └───────────────────────────┘
```

### Component Breakdown
1. **Header & Navigation**: Sticky single-row top bar with smooth scrolling jump handlers.
2. **Background Engine**: `<CanvasStarfield />` managing particle drift, twinkling, and reduced-motion detection.
3. **Revolving Moon**: `<RevolvingMoon />` SVG component with CSS continuous keyframe rotation and orbital ring animation.
4. **WATCHTOWER**: Score gauge component + metric cards (Cloud Cover, Humidity, Visibility, Wind, Light Pollution).
5. **CELESTIAL SCROLL**: Event list with multi-category filters (Meteor Shower, Eclipse, ISS, Moon Phase) and date range filters.
6. **SPIRIT LENS**: Image dropzone, comparison slider (Before/After), enhancement controls, object detection tags, and Express/Gemini integration.
7. **DOJO DASHBOARD**: Responsive grid summarizing overall stargazing telemetry and quick actions.
